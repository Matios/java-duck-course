
var img2=null;
var imgcanvas2=null;
var finput=null;
function upload(){
   imgcanvas2= document.getElementById("c2");
   finput=document.getElementById("finput");
 // var ctx=imgcanvas2.getContext("2d");
   //ctx.moveTo(0, 0);
//ctx.lineTo(200, 100);
//ctx.stroke();
  img2=new SimpleImage(finput);
  img2.drawTo(imgcanvas2);
 
}
function makeGray(){
  for(var pixel of img2.values()){
    var avg =(pixel.getRed()+ pixel.getGreen()+pixel.getBlue())/3;
    pixel.setBlue(avg);
    pixel.setRed(avg);
    pixel.setGreen(avg);
}
 var imgcanvas= document.getElementById("c2");
  img2.drawTo(imgcanvas);
}
function makeRed(){
  var avr;
  for(var pixel of img2.values()){
     avr =(pixel.getRed()+pixel.getBlue()+pixel.getGreen())/3;
  

  if(avr < 128){
    pixel.setRed(avr*2);
    pixel.setBlue(0);
    pixel.setGreen(0);
  }
  else{
    pixel.setRed(255);
    pixel.setBlue(2*avr - 255);
    pixel.setGreen(2*avr -255);
  }
  }
 var imgcanvas= document.getElementById("c2");
 img2.drawTo(imgcanvas);
}
function rainBow(){
  var height=img2.getHeight();

for(var pixel of img2.values()){
    var av=(pixel.getRed()+pixel.getBlue()+pixel.getRed())/3;
if(pixel.getY() < height/7){
    if(av < 128){
        pixel.setRed(2*av);
        pixel.setGreen(0);
        pixel.setBlue(0);
        
    }
    else{
        pixel.setRed(255);
        pixel.setGreen(2*av -255 );
        pixel.setBlue(2*av -255);
        
    }
  }
  else if((pixel.getY() > height/7) && (pixel.getY() < (height * 2)/7)){
      
       if(av < 128){
        pixel.setRed(2*av);
        pixel.setBlue(0.8 * av);
        pixel.setGreen(0);
    }
    else{
        pixel.setRed(255);
        pixel.setGreen(1.2*av -51);
        pixel.setBlue(2*av -255 );
    }
  }
   else if((pixel.getY() > (height*2)/7) && (pixel.getY() < (height * 3)/7)){
       if(av < 128){
      pixel.setRed(2*av);
       pixel.setGreen(2*av);
        pixel.setBlue(0);
       //yellow
    }
    else{
        pixel.setRed(255);
        pixel.setGreen(255 );
        pixel.setBlue(2*av - 255);
        
    }
  }
    else if((pixel.getY() > (height*3)/7) && (pixel.getY() < (height * 4)/7)){
       if(av < 128){
        pixel.setRed(0);
        pixel.setGreen(2*av);
        pixel.setBlue(0);
    }//Green
    else{
        pixel.setRed(2*av -255);
        pixel.setGreen(255);
        pixel.setBlue(2*av -255 );
    }
  }
   else if((pixel.getY() > (height*4)/7) && (pixel.getY() < (height * 5)/7)){
       if(av < 128){
        pixel.setRed(0);
        pixel.setGreen(0);
        pixel.setBlue(2*av);
    }//BLUE
    else{
        pixel.setRed(2*av -255);
        pixel.setGreen(2 * av -255);
        pixel.setBlue(255 );
    }
  }
   else if((pixel.getY() > (height*5)/7) && (pixel.getY() < (height * 6)/7)){
       if(av < 128){
        pixel.setRed(0.8*av);
        pixel.setGreen(0);
        pixel.setBlue(2*av);
    }//Indigo
    else{
        pixel.setRed(1.2*av -51);
        pixel.setGreen(2*av - 255);
        pixel.setBlue(255 );
    }
  }
 else{
       if(av < 128){
        pixel.setRed(1.6*av);
        pixel.setGreen(0);
        pixel.setBlue(1.6*av);
    }//Violet
    else{
        pixel.setRed(0.4*av +153);
        pixel.setGreen(2*av-255);
        pixel.setBlue(0.4*av +153 );
    }
  }}
  var imgcanvas= document.getElementById("c2");
 img2.drawTo(imgcanvas);
}
function blurry(){
  for()
}
function reset(){
  imgcanvas2= document.getElementById("c2");
  if(imgcanvas2 != null){
  img2=new SimpleImage(finput);
  }
  img2.drawTo(imgcanvas2);
}